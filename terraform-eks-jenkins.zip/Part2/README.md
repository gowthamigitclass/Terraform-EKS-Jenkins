Jenkins pipeline to trigger and deploy EKS cluster with terraform module calls

Deploy AWS EKS via a Jenkins job using terraform. The idea here is to easily deploy EKS to AWS, specifying some settings via pipeline parameters.

Jenkins pipeline

Jenkins needs the following linux commands, which can either be installed via the Linux package manager or in the case of terraform, downloaded:

terraform (0.12.x)
jq
kubectl
The pipeline uses a terraform workspace for each cluster name, so you should be safe deploying multiple clusters via the same Jenkins job. Obviously state is maintained in the Jenkins job workspace (see To do below).

Store terraform state in an s3 bucket
This the recommended method, as keeping the stack in the workspace of the Jenkins job is a bad idea! See terraform docs for this. You can probably add a Jenkins parameter for the bucket name, and get the Jenkins job to construct the config for the state before running terraform.

Implement locking for terraform state using dynamodb
Similar to state, this ensure multiple runs of terraform cannot happen. See terraform docs for this. Again you might wish to get the dynamodb table name as a Jenkins parameter.

We are using terraform to create our infrastructure code and helm charts to deploy kubernetes resources.

Have a separate repo to create the EKS cluster. Output the eks endpoints from the repo.

Have every service that need to be deployed to EKS use those terraform output variables and then create the helm chart via terraform.